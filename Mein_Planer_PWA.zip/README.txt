MEIN PLANER – INSTALLATION

Die App ist eine private Progressive Web App (PWA).

1. Lade den Ordner auf einen kostenlosen HTTPS-Webhost hoch, z. B. GitHub Pages oder Cloudflare Pages.
2. Öffne die Adresse auf iPhone oder iPad in Safari.
3. Tippe auf Teilen → „Zum Home-Bildschirm“.
4. Danach startet die App wie eine normale App.

Wichtig:
- Keine Werbung.
- Keine fremden Benutzer.
- Die aktuelle Version speichert Daten nur lokal auf dem jeweiligen Gerät.
- Dadurch werden Daten NOCH NICHT automatisch zwischen iPhone und iPad synchronisiert.
- Für echte Gerätesynchronisation braucht die App einen privaten Cloud-Speicher (z. B. Supabase/Firebase/iCloud-basierte Lösung).
